﻿namespace StudentCqrsApiProject.Features.Students
{
    public class StudentDto
    {
        public string Name { get; set; } = "";
        public int Age { get; set; }
    }
}

