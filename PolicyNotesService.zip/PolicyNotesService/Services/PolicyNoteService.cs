﻿using PolicyNotesService.Models;
using PolicyNotesService.Repositories;

namespace PolicyNotesService.Services
{
    public class PolicyNoteService : IPolicyNoteService
    {
        private readonly IPolicyNoteRepository _repository;

        public PolicyNoteService(IPolicyNoteRepository repository)
        {
            _repository = repository;
        }

        public async Task<PolicyNote> AddNoteAsync(PolicyNoteCreateDto dto)
        {
            if (string.IsNullOrWhiteSpace(dto.PolicyNumber))
            {
                throw new ArgumentException("PolicyNumber is required", nameof(dto.PolicyNumber));
            }

            if (string.IsNullOrWhiteSpace(dto.Note))
            {
                throw new ArgumentException("Note is required", nameof(dto.Note));
            }

            var entity = new PolicyNote
            {
                PolicyNumber = dto.PolicyNumber,
                Note = dto.Note
            };

            return await _repository.AddAsync(entity);
        }

        public Task<List<PolicyNote>> GetAllAsync()
        {
            return _repository.GetAllAsync();
        }

        public Task<PolicyNote?> GetByIdAsync(int id)
        {
            return _repository.GetByIdAsync(id);
        }

        public Task<List<PolicyNote>> GetByPolicyNumberAsync(string policyNumber)
        {
            return _repository.GetByPolicyNumberAsync(policyNumber);
        }
    }
}

