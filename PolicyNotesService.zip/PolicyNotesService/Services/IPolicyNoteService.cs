﻿using PolicyNotesService.Models;

namespace PolicyNotesService.Services
{
    public interface IPolicyNoteService
    {
        Task<PolicyNote> AddNoteAsync(PolicyNoteCreateDto dto);
        Task<List<PolicyNote>> GetAllAsync();
        Task<PolicyNote?> GetByIdAsync(int id);
        Task<List<PolicyNote>> GetByPolicyNumberAsync(string policyNumber);
    }
}

