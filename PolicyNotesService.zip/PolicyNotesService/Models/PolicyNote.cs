﻿namespace PolicyNotesService.Models
{
    // This is the entity stored in the database
    public class PolicyNote
    {
        public int Id { get; set; }                // Primary key
        public string PolicyNumber { get; set; } = string.Empty;
        public string Note { get; set; } = string.Empty;
    }

    // DTO used for creating a note (no Id from client)
    public class PolicyNoteCreateDto
    {
        public string PolicyNumber { get; set; } = string.Empty;
        public string Note { get; set; } = string.Empty;
    }
}

