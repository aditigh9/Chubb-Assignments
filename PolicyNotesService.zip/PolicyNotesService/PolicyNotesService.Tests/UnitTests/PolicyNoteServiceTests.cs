﻿using System;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using PolicyNotesService.Data;
using PolicyNotesService.Repositories;
using PolicyNotesService.Services;
using PolicyNotesService.Models;
using Xunit;

namespace PolicyNotesService.Tests.UnitTests
{
    public class PolicyNoteServiceTests
    {
        // Creates a fresh in-memory DB + service for each test
        private static PolicyNoteService CreateService()
        {
            var options = new DbContextOptionsBuilder<PolicyNotesDbContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            var context = new PolicyNotesDbContext(options);
            var repo = new PolicyNoteRepository(context);
            return new PolicyNoteService(repo);
        }

        [Fact]
        public async Task AddNote_Should_AssignId_And_Save()
        {
            var service = CreateService();
            var dto = new PolicyNoteCreateDto
            {
                PolicyNumber = "UNIT001",
                Note = "Unit testing add note"
            };

            var created = await service.AddNoteAsync(dto);

            Assert.True(created.Id > 0);
            Assert.Equal("UNIT001", created.PolicyNumber);
            Assert.Equal("Unit testing add note", created.Note);
        }

        [Fact]
        public async Task GetAll_Should_ReturnNotes()
        {
            var service = CreateService();

            await service.AddNoteAsync(new PolicyNoteCreateDto
            {
                PolicyNumber = "UNIT002",
                Note = "First note"
            });

            var list = await service.GetAllAsync();

            Assert.NotNull(list);
            Assert.Single(list);
        }
    }
}

