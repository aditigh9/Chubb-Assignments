﻿using System.Net;
using System.Net.Http.Json;
using Microsoft.AspNetCore.Mvc.Testing;
using PolicyNotesService.Models;
using Xunit;

namespace PolicyNotesService.Tests.IntegrationTests
{
    public class PolicyNotesApiTests : IClassFixture<WebApplicationFactory<Program>>
    {
        private readonly WebApplicationFactory<Program> _factory;

        public PolicyNotesApiTests(WebApplicationFactory<Program> factory)
        {
            _factory = factory;
        }

        [Fact]
        public async Task PostNotes_Should_ReturnCreated()
        {
            var client = _factory.CreateClient();

            var dto = new PolicyNoteCreateDto
            {
                PolicyNumber = "INT001",
                Note = "Integration test note"
            };

            var response = await client.PostAsJsonAsync("/notes", dto);

            Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        }

        [Fact]
        public async Task GetNotes_Should_ReturnOk()
        {
            var client = _factory.CreateClient();

            await client.PostAsJsonAsync("/notes", new PolicyNoteCreateDto
            {
                PolicyNumber = "INT002",
                Note = "Testing GET"
            });

            var response = await client.GetAsync("/notes");

            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        }

        [Fact]
        public async Task GetNoteById_Should_ReturnOk_IfExists_AndNotFound_IfMissing()
        {
            var client = _factory.CreateClient();

            var createResponse = await client.PostAsJsonAsync("/notes", new PolicyNoteCreateDto
            {
                PolicyNumber = "INT003",
                Note = "Check ID lookup"
            });

            var created = await createResponse.Content.ReadFromJsonAsync<PolicyNote>();

            var found = await client.GetAsync($"/notes/{created!.Id}");
            Assert.Equal(HttpStatusCode.OK, found.StatusCode);

            var missing = await client.GetAsync("/notes/999999");
            Assert.Equal(HttpStatusCode.NotFound, missing.StatusCode);
        }
    }
}

