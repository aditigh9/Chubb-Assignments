using Microsoft.EntityFrameworkCore;
using PolicyNotesService.Data;
using PolicyNotesService.Models;
using PolicyNotesService.Repositories;
using PolicyNotesService.Services;

var builder = WebApplication.CreateBuilder(args);

// Register DbContext with InMemory database
builder.Services.AddDbContext<PolicyNotesDbContext>(options =>
    options.UseInMemoryDatabase("PolicyNotesDb"));

// Register Repository and Service
builder.Services.AddScoped<IPolicyNoteRepository, PolicyNoteRepository>();
builder.Services.AddScoped<IPolicyNoteService, PolicyNoteService>();

// Swagger/OpenAPI
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Enable Swagger UI in Development
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// POST /notes - create a new note
app.MapPost("/notes", async (PolicyNoteCreateDto dto, IPolicyNoteService service) =>
{
    var created = await service.AddNoteAsync(dto);
    return Results.Created($"/notes/{created.Id}", created);
});

// GET /notes - get all notes
app.MapGet("/notes", async (IPolicyNoteService service) =>
{
    var notes = await service.GetAllAsync();
    return Results.Ok(notes);
});

// GET /notes/{id} - get note by id
app.MapGet("/notes/{id:int}", async (int id, IPolicyNoteService service) =>
{
    var note = await service.GetByIdAsync(id);
    return note is null ? Results.NotFound() : Results.Ok(note);
});

// Optional: GET /notes/policy/{policyNumber} - all notes for a policy
app.MapGet("/notes/policy/{policyNumber}", async (string policyNumber, IPolicyNoteService service) =>
{
    var notes = await service.GetByPolicyNumberAsync(policyNumber);
    return Results.Ok(notes);
});

app.Run();

// Needed for WebApplicationFactory in integration tests
public partial class Program { }
