﻿using Microsoft.EntityFrameworkCore;
using PolicyNotesService.Data;
using PolicyNotesService.Models;

namespace PolicyNotesService.Repositories
{
    public class PolicyNoteRepository : IPolicyNoteRepository
    {
        private readonly PolicyNotesDbContext _context;

        public PolicyNoteRepository(PolicyNotesDbContext context)
        {
            _context = context;
        }

        public async Task<PolicyNote> AddAsync(PolicyNote note)
        {
            _context.PolicyNotes.Add(note);
            await _context.SaveChangesAsync();
            return note;
        }

        public Task<List<PolicyNote>> GetAllAsync()
        {
            return _context.PolicyNotes
                .AsNoTracking()
                .ToListAsync();
        }

        public Task<PolicyNote?> GetByIdAsync(int id)
        {
            return _context.PolicyNotes
                .AsNoTracking()
                .FirstOrDefaultAsync(n => n.Id == id);
        }

        public Task<List<PolicyNote>> GetByPolicyNumberAsync(string policyNumber)
        {
            return _context.PolicyNotes
                .AsNoTracking()
                .Where(n => n.PolicyNumber == policyNumber)
                .ToListAsync();
        }
    }
}

